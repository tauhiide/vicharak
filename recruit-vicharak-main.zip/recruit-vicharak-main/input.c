/* Syntax :
Variable Declartion : int<identifier>;
Assignment: <identifer> = <expression>;
Arithmetic: <expression> ::=<term> | <term> + <term> | <term> - <term> 
Conditional : if(<expression> == <expression>) {<statement>}
*/
// Example:
int a;
int b;
int c;
a = 10;
b = 20;
c = a+b;
if(c==30){
c = c+1;
}
